#include<stdlib.h> 
#include<string.h>
#include<stdio.h> 
int main()
{
    write(1,"hello world",strlen("hello world")); 


    return 0;
}

