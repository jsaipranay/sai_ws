#include<stdio.h> 
inline void fun()
{
printf("hello....\n");
}

int main(void)
{

fun();
return 0;
}

