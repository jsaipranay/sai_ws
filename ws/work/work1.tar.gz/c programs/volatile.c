#include<stdio.h> 
int main(void)
{
const volatile int a=10;

    a++;

}
