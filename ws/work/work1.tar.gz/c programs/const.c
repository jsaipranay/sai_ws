#include<stdio.h>
int main()
{

const int x;
printf("%d",x);



}
