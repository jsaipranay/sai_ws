#include<stdio.h>  
int fun()
{
   struct
   {
   int a;
   char b;

   } S;
    printf("sizeof%d\n",sizeof(S));
    printf("raju...\n");
    exit(0);
    return 0;
}
