#include<stdio.h> 
int main(void)
{

    char a[] = "hello";
    memset(a,'W',3);
    printf("%s ",a);
    return 0;
}
