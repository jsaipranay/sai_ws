class Empty
{
public:
get_employee_info()
{

int emp_number;
char emp_name[10];
char emp_designation[10];
}

};
class Salary : public Empty
{
get_salary_info()
{
int basic_pay;
cout >> "BASIC_PAY">>endl;
cin >> basic_pay;

int HRA;
cout >> "enter HRA">>endl;
cin >> HRA;

int DA;
cout >> "enter DA">>endl;
cin >>DA;
cout >> "enter PF">>endl;
int PF;
cin >>PF;

}
calculate()
{

return basic_pay +HRA+DA+PF;

}
}
display()
{
cout<<

}

};

main()
{
salary s[20];

cout <<"enter no of employs">>endl;
cin >>no.ofemploys;
s.get_employee_info();
s.get_salary_info();
s.calculate();
display();


}
