#include<iostream>
using namespace std;
public:
mycounter()
{
cout < "my counter()"<<endl;
}
void setevent(int x)
{
numof events=x;

}
mycounter& docountup()
{

++numofevents;
return this;
}
void display
{

cout <<id << " : "numofevents <<endl;
}
}
main(
{





}
