#include<iostream>
using namespace std;
/*void dosomething(int x=0)
{




}
void dosomething()
{



}
int main()
{

dosomething();


}*/

void dosomething(int x)
{



}
void dosomething(int &x)
{

}
int main()
{
int x=10;
dosomething(x);


}

