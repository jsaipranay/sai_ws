 #include<stdio.h>
int main()
{
   int i,a=0;
   for(i=0;i<=255;i++)
   {
   printf("%d:%c\n",a,i);
   a++;
  }

}
