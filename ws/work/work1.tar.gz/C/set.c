#include <stdio.h>
 main()
{
 int num,n,newnum;
scanf("%d",&num);
scanf("%d",&n);
newnum=num^(1<<n);
printf("%d\n",newnum);



/*set bit to 1:
newnum=num|(1<<n);

clear bit:
newnum=num&(~(1<<n));

toggle bit:
newnum=num^(1<<n);




} 

